service.subtitles..301IS-CRCV
==========================

3-01 Ingenieria en Software, add-on de subtitulos para XBMC

Roadmap
==============

v1.0

*   Haga que el indicador de sincronización aparezca en los subtítulos que se sincronizan versión de la traducción original